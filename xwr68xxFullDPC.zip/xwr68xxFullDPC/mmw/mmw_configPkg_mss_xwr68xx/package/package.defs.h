/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-E10
 */

#ifndef mmw_configPkg_mss_xwr68xx__
#define mmw_configPkg_mss_xwr68xx__



#endif /* mmw_configPkg_mss_xwr68xx__ */ 
